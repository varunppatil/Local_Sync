import { setWorldConstructor } from "@cucumber/cucumber";
import { expect, Locator, Page} from "@playwright/test"

export class LoginPage {

  /*  readonly page:Page;
    readonly locator:Locator;


constructor (page:Page){

    this.page =page;
  //  this.Password=

}

async launchURL()  {
    this.page.goto("https://demo.opencart.com/");
}

async click(){
//    this.page.locator().click;
}


*/

}