import{context, Given, When, setDefaultTimeout, Then} from "@cucumber/cucumber"
import {chromium,expect} from "@playwright/test"
import { LoginPage } from "../../Pages/LoginPage";
setDefaultTimeout(60*1000);



const data = JSON.parse(JSON.stringify(require("../TestData/Locators.json")));
const data1 = JSON.stringify(require("../TestData/Locators.json"));

    Given('I launch application', async function () {
        this.browser = await chromium.launch({headless:false});
        this.context = await this.browser.newContext();
        this.page = await this.context.newPage();
      //  const loginPage =new LoginPage(this.page);
      //  loginPage.launchURL();
        await this.page.goto("https://demo.opencart.com.gr/");
    });
    
    When('I should see {string} title', async function (title:string) {
        await expect (this.page).toHaveTitle(title);
    });
    
    When('I click on My Account', async function () {
        await this.page.locator("//span[text()='My Account']").click();
    });

    When('I click on Register', async function () {
        
        await this.page.locator("//a[text()='Register']").click();
    });
    
    When('I click on First_Name field and enter {string}', async function (text:string) {
        
        await this.page.locator("[id='input-firstname']").click();
        await this.page.locator("[id='input-firstname']").fill(text);
      });


      When('I click on Last_Name field and enter {string}', async function (text:string) {
        
        await this.page.locator("//*[@id='input-lastname']").click();
        await this.page.locator("//*[@id='input-lastname']").fill(text);
      });

      When('I click on Email field and enter {string}', async function (text:string) {
        
        await this.page.locator("//*[@id='input-email']").click();
        await this.page.locator("//*[@id='input-email']").fill(text);
      });

      When('I click on Telephone field and enter {string}', async function (text:string) {
        
        await this.page.locator("//*[@id='input-telephone']").click();
        await this.page.locator("//*[@id='input-telephone']").fill(text);
      });

      When('I click on Password field and enter {string}', async function (text:string) {
        
        await this.page.locator("//*[@id='input-password']").click();
        await this.page.locator("//*[@id='input-password']").fill(text);
      });
      
      When('I click on Confirm Password field and enter {string}', async function (text:string) {
        
        await this.page.locator("//*[@id='input-confirm']").click();
        await this.page.locator("//*[@id='input-confirm']").fill(text);
      });

    When('I click on Privacy_Policy', async function () {
        
        await this.page.locator("//*[@name='agree']").click();
    });
    
    When('I click on Continue', async function () {
        
        await this.page.locator("//*[@type='submit']").click();
    });


    Then('I should see Account_Created_Message', async function (xpathName:string) {
        await expect (this.page.locator("//*[text()='Congratulations! Your new account has been successfully created!']")).toBeVisible();
      });

  