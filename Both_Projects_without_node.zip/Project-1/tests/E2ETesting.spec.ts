import {expect, test} from '@playwright/test';
import { Console } from 'console';

let numbers:any[]=[3424, 34, 34, 424, 75676]  

//Register with multiple username and running register case not to fail for same username
for (let num in numbers ){
test("Verify registration for user something"+num+"",async ({page})=>{
  //Follow the steps - login button click, register, fill details and you will get registered as user
  await page.goto("https://bookcart.azurewebsites.net/") ;
  await page.locator("//span[text()=' Login ']").click();
  await page.locator("//span[text()='Register']").click();
  await page.locator("input[id='mat-input-2']").fill("Varun");
  await page.locator("input[id='mat-input-3']").fill("Patil");
  await page.locator("input[id='mat-input-4']").fill("something"+num);
  await page.locator("input[id='mat-input-5']").fill("Va#567890");
  await page.locator("input[id='mat-input-6']").fill("Va#567890");
  //Register text disappering so fast so need to validate like we navigate to same page validating Register button
  await expect(page.locator("//span[text()='Register']")).toBeVisible(); 
});
}

//Login and check 'Catching Fire' book
test("Verify login with user credentials",async ({page})=>{
await page.goto("https://bookcart.azurewebsites.net/") ;
await page.locator("//span[text()=' Login ']").click();
//Enter username and password
await page.locator("//input[@id='mat-input-0']").fill("varunpp");
await page.locator("//input[@id='mat-input-1']").fill("Va#567890");
//Login
await page.locator("//span[text()='Login']").click();
//Click and search book catching fire
await page.locator("input[type='search']").click();
await page.locator("input[type='search']").fill("Catching Fire");
//Click on book
await page.locator("//span[text()=' Catching Fire ']").click();
//check book is present or not - Catching Fire 
await expect(page.locator("//strong[text()='Catching Fire']")).toHaveText('Catching Fire');
await expect(page.locator("//strong[text()='Catching Fire']")).toBeVisible();
});

//Add to cart and check if it's present
test("Verify shopping cart functionality",async ({page})=>{
  await page.goto("https://bookcart.azurewebsites.net/") ;
  await page.locator("//span[text()=' Login ']").click();
  //Enter username and password
  await page.locator("//input[@id='mat-input-0']").fill("varunpp");
  await page.locator("//input[@id='mat-input-1']").fill("Va#567890");
  //Login
  await page.locator("//span[text()='Login']").click();
  //Click and search book catching fire
  await page.locator("input[type='search']").click();
  await page.locator("input[type='search']").fill("Catching Fire");
  //Click on book
  await page.locator("//span[text()=' Catching Fire ']").click();
  //check book is present or not - Catching Fire 
  await expect(page.locator("//strong[text()='Catching Fire']")).toHaveText('Catching Fire');
  await expect(page.locator("//strong[text()='Catching Fire']")).toBeVisible();
  //Add to cart and click on
  await page.locator("//span[contains(text(),'to Cart')]").click();
  await page.locator("[id='mat-badge-content-0']").click();
  //Checking book - Due to css required so using href
  await page.waitForTimeout(4000);
  await expect(page.locator("a[href='/books/details/46']")).toHaveText('Catching Fire');
  });

//Add to cart and check if it's present and clear cart
test("Verify clear cart functionality",async ({page})=>{
  await page.goto("https://bookcart.azurewebsites.net/") ;
  await page.locator("//span[text()=' Login ']").click();
  //Enter username and password
  await page.locator("//input[@id='mat-input-0']").fill("varunpp");
  await page.locator("//input[@id='mat-input-1']").fill("Va#567890");
  //Login
  await page.locator("//span[text()='Login']").click();
  //Click and search book catching fire
  await page.locator("input[type='search']").click();
  await page.locator("input[type='search']").fill("Catching Fire");
  //Click on book
  await page.locator("//span[text()=' Catching Fire ']").click();
  //check book is present or not - Catching Fire 
  await expect(page.locator("//strong[text()='Catching Fire']")).toHaveText('Catching Fire');
  await expect(page.locator("//strong[text()='Catching Fire']")).toBeVisible();
  //Add to cart and click on
  await page.locator("//span[contains(text(),'to Cart')]").click();
  await page.locator("[id='mat-badge-content-0']").click();
  //Due to css required so using href
  await page.waitForTimeout(4000);
  await expect(page.locator("a[href='/books/details/46']")).toHaveText('Catching Fire');
  //Clear Cart
  await page.locator("//span[text()=' Clear cart ']").click();
  //Verify cart is empty message
  await expect(page.locator("//*[text()='Your shopping cart is empty.']")).toHaveText('Your shopping cart is empty.');
  });

  //Delete cart
  test("Verify delete cart functionality",async ({page})=>{
    await page.goto("https://bookcart.azurewebsites.net/") ;
    await page.locator("//span[text()=' Login ']").click();
    //Enter username and password
    await page.locator("//input[@id='mat-input-0']").fill("varunpp");
    await page.locator("//input[@id='mat-input-1']").fill("Va#567890");
    //Login
    await page.locator("//span[text()='Login']").click();
    //Click and search book catching fire
    await page.locator("input[type='search']").click();
    await page.locator("input[type='search']").fill("Catching Fire");
    //Click on book
    await page.locator("//span[text()=' Catching Fire ']").click();
    //check book is present or not - Catching Fire 
    await expect(page.locator("//strong[text()='Catching Fire']")).toHaveText('Catching Fire');
    await expect(page.locator("//strong[text()='Catching Fire']")).toBeVisible();
    //Add to cart and click on
    await page.locator("//span[contains(text(),'to Cart')]").click();
    await page.locator("[id='mat-badge-content-0']").click();
    //Due to css required so using href
    await page.waitForTimeout(4000);
    await expect(page.locator("a[href='/books/details/46']")).toHaveText('Catching Fire');
    //Clicking Delete Cart
    await page.locator("//*[text()='delete']").click();
    //Verify cart is empty message
    await expect(page.locator("//*[text()='Your shopping cart is empty.']")).toHaveText('Your shopping cart is empty.');
    });

    //Book details Scenario
    test("Verify Books details",async ({page})=>{
      await page.goto("https://bookcart.azurewebsites.net/") ;
      await page.locator("//span[text()=' Login ']").click();
      //Enter username and password
      await page.locator("//input[@id='mat-input-0']").fill("varunpp");
      await page.locator("//input[@id='mat-input-1']").fill("Va#567890");
      //Login
      await page.locator("//span[text()='Login']").click();
      //Click and search book catching fire
      await page.locator("input[type='search']").click();
      await page.locator("input[type='search']").fill("Catching Fire");
      //check book is present and click on it - Catching Fire 
      await expect(page.locator("//strong[text()='Catching Fire']")).toHaveText('Catching Fire');
      await expect(page.locator("//strong[text()='Catching Fire']")).toBeVisible();
      await page.locator("//strong[text()='Catching Fire']").click();
     
      // Verify book details using 1 xpath with array
      let a:string[]=['Catching Fire', 'Suzanne Collins', 'Mystery','₹658.00']     
      for(let i=0;i<a.length;i++){
        await page.waitForTimeout(2000);
        console.log(a[i]);
        await expect(page.locator("//*[text()='"+a[i]+"']")).toHaveText(a[i]);
        await expect(page.locator("//*[text()='"+a[i]+"']")).toBeVisible();
      }
      });
      
      //Add to wishlist
      test("Verify that book is added in wishlist",async ({page})=>{
      await page.goto("https://bookcart.azurewebsites.net/") ;
      await page.locator("//span[text()=' Login ']").click();
      //Enter username and password
      await page.locator("//input[@id='mat-input-0']").fill("varunpp");
      await page.locator("//input[@id='mat-input-1']").fill("Va#567890");
      //Login
      await page.locator("//span[text()='Login']").click();
      //Click and search book catching fire
      await page.locator("input[type='search']").click();
      await page.locator("input[type='search']").fill("Catching Fire");
      //check book is present and click on it - Catching Fire 
      await expect(page.locator("//strong[text()='Catching Fire']")).toHaveText('Catching Fire');
      await expect(page.locator("//strong[text()='Catching Fire']")).toBeVisible();
      await page.locator("//strong[text()='Catching Fire']").click();
     
      // Add to wish option is not getting - xpath have also probelm so use absolute xpath
      //Changed xpath
      await page.waitForTimeout(2000);
      await page.locator("//*[contains(text(),' Add to Wishlist')]").click();
      await page.locator("//*[text()='favorite']").click();
      await expect(page.locator("//a[text()='Catching Fire']")).toBeVisible();
      });

      //Remove from wishlist
      test("Verify that book is removed from wishlist",async ({page})=>{
        await page.goto("https://bookcart.azurewebsites.net/") ;
        await page.locator("//span[text()=' Login ']").click();
        //Enter username and password
        await page.locator("//input[@id='mat-input-0']").fill("varunpp");
        await page.locator("//input[@id='mat-input-1']").fill("Va#567890");
        //Login
        await page.locator("//span[text()='Login']").click();
        //Click and search book catching fire
        await page.locator("input[type='search']").click();
        await page.locator("input[type='search']").fill("Catching Fire");
        //check book is present and click on it - Catching Fire 
        await expect(page.locator("//strong[text()='Catching Fire']")).toHaveText('Catching Fire');
        await expect(page.locator("//strong[text()='Catching Fire']")).toBeVisible();
        await page.locator("//strong[text()='Catching Fire']").click();
      
        // Add to wish option is not getting - xpath have also probelm so use absolute xpath
        //Changed xpath
        await page.waitForTimeout(2000);
        await page.locator("//*[contains(text(),' Add to Wishlist')]").click();
        await page.locator("//*[text()='favorite']").click();
        await expect(page.locator("//a[text()='Catching Fire']")).toBeVisible();
        //Remove book from wishlist
        await page.locator("//span[contains(text(),' Remove from Wishlist')]").click();
        await expect(page.locator("//*[contains(text(),'Your wishlist is empty.')]")).toBeVisible();
        });

        //Add to cart and checkout and fill details and logout
        test("Verify add to cart, checkout and logout",async ({page})=>{
          await page.goto("https://bookcart.azurewebsites.net/") ;
          await page.locator("//span[text()=' Login ']").click();
          //Enter username and password
          await page.locator("//input[@id='mat-input-0']").fill("varunpp");
          await page.locator("//input[@id='mat-input-1']").fill("Va#567890");
          //Login
          await page.locator("//span[text()='Login']").click();
          //Click and search book catching fire
          await page.locator("input[type='search']").click();
          await page.locator("input[type='search']").fill("Catching Fire");
          //Click on book
          await page.locator("//span[text()=' Catching Fire ']").click();
          //check book is present or not - Catching Fire 
          await expect(page.locator("//strong[text()='Catching Fire']")).toHaveText('Catching Fire');
          await expect(page.locator("//strong[text()='Catching Fire']")).toBeVisible();
          //Add to cart and click on
          await page.locator("//span[contains(text(),'to Cart')]").click();
          await page.locator("[id='mat-badge-content-0']").click();
          //Due to css required so using href
          await page.waitForTimeout(4000);
          await expect(page.locator("a[href='/books/details/46']")).toHaveText('Catching Fire');
          //chckout
          await page.locator("//*[contains(text(),'CheckOut')]").click();
          //Filling deatails, adding dynamic index in xpath and using array value as well
          let a:string[]=['Varun P', 'Phase 3', 'Pune','411057', 'Maharashtra']     
          for(let i=0;i<a.length;i++){
            await page.waitForTimeout(2000);
            console.log(a[i]);
            await page.locator("//input[@id='mat-input-"+(i+2)+"']").click();
            await page.locator("//input[@id='mat-input-"+(i+2)+"']").fill(a[i]);
          }
          //Place order
          await page.waitForTimeout(2000);
          await page.locator("//*[text()=' Place Order ']").click();
          //await page.locator("//*[text()=' Place Order ']//following-sibling::span[contains(@class,'button')]").click();
          //Print order id
          await page.waitForTimeout(5000);
          let orderId = await page.locator("//tr[1]//td[contains(@class,'orderId')]").textContent();
          console.log(orderId);
          //Verify Price  
          let price = await page.locator("//tr[1]//td[contains(@class,'cartTotal')]").textContent();
          console.log(price);
          await expect(page.locator("//tr[1]//td[contains(@class,'cartTotal')]")).toHaveText(" ₹658.00 ");
          //Logout
          await page.locator("//*[text()='arrow_drop_down']").click();
          await page.locator("//*[text()='Logout']").click();
        });
