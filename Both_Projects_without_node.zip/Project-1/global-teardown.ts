async function globalTearDown(){

console.log("Global teardown");

}

export default globalTearDown;